vti_encoding:SR|utf8-nl
vti_author:SR|lenovo-PC\\lenovo
vti_modifiedby:SR|lenovo-PC\\lenovo
vti_timelastmodified:TR|14 Oct 2012 08:02:18 -0000
vti_timecreated:TR|14 Oct 2012 08:02:18 -0000
vti_cacheddtm:TX|14 Oct 2012 08:02:18 -0000
vti_filesize:IR|9642
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|index1.html
