vti_encoding:SR|utf8-nl
vti_author:SR|小石头\\CraigTaylor
vti_modifiedby:SR|小石头\\CraigTaylor
vti_timelastmodified:TR|13 Oct 2012 20:03:11 -0000
vti_timecreated:TR|13 Oct 2012 08:15:02 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|
vti_nexttolasttimemodified:TW|13 Oct 2012 08:16:09 -0000
vti_cacheddtm:TX|13 Oct 2012 20:03:11 -0000
vti_filesize:IR|9642
