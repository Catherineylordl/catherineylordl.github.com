vti_encoding:SR|utf8-nl
vti_author:SR|小石头\\CraigTaylor
vti_modifiedby:SR|小石头\\CraigTaylor
vti_timelastmodified:TR|14 Oct 2012 04:01:06 -0000
vti_timecreated:TR|14 Oct 2012 04:00:58 -0000
vti_extenderversion:SR|12.0.0.0
vti_backlinkinfo:VX|Catherine.html
vti_nexttolasttimemodified:TW|14 Oct 2012 04:00:59 -0000
vti_cacheddtm:TX|14 Oct 2012 04:01:06 -0000
vti_filesize:IR|35750
